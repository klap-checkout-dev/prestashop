<?php

namespace PrestaShop\Module\Klap\Install;

use Db;

class KlapInstaller
{
    public function installKlapTransactionTable()
    {
        $sql = 'CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'klap_transaction` (
                `id` bigint(20) NOT NULL AUTO_INCREMENT,
                `cart_id` varchar(100) NOT NULL UNIQUE,
                `pedido_id` varchar(100),
                `mc_code` varchar(100),
                `order_id` varchar(100),
                `amount` bigint(20) NOT NULL,
                `status` tinyint(3) NOT NULL,
                `card_number` varchar(20) NOT NULL,
                `card_brand` varchar(50) NOT NULL,
                `card_holder` varchar(100) NOT NULL,
                `card_last_digits` varchar(4) NOT NULL,
                `transaction_type` varchar(50) NOT NULL,
                `installments` int(11) NOT NULL,
                `installment_amount` bigint(20) NOT NULL,
                `authorization_code` varchar(50) NOT NULL,
                `klap_data` TEXT,
                `created_at` TIMESTAMP NOT NULL DEFAULT NOW(),
                 PRIMARY KEY (id)) ENGINE='._MYSQL_ENGINE_.' DEFAULT CHARSET=utf8;';
        Db::getInstance()->execute($sql);
        if (Db::getInstance()->getNumberError() != 0) {
            return false;
        }
        $this->upgrade_module_2_1_4();
        
        return true;
    }

    function upgrade_module_2_1_4()
    {
        $sql = [];

        $columnsToAdd = [
            'card_number' => 'varchar(20) NOT NULL',
            'card_brand' => 'varchar(50) NOT NULL',
            'card_holder' => 'varchar(100) NOT NULL',
            'card_last_digits' => 'varchar(4) NOT NULL',
            'transaction_type' => 'varchar(50) NOT NULL',
            'installments' => 'int(11) NOT NULL',
            'installment_amount' => 'bigint(20) NOT NULL',
            'authorization_code' => 'varchar(50) NOT NULL',
        ];

        foreach ($columnsToAdd as $column => $definition) {
            $check = Db::getInstance()->executeS("
                SHOW COLUMNS FROM `" . _DB_PREFIX_ . "klap_transaction` LIKE '$column'
            ");
            if (empty($check)) {
                $sql[] = "ALTER TABLE `" . _DB_PREFIX_ . "klap_transaction` ADD `$column` $definition";
            }
        }

        foreach ($sql as $query) {
            Db::getInstance()->execute($query);
            if (Db::getInstance()->getNumberError() != 0) {
                return false;
            }
        }

        return true;
    }
}
