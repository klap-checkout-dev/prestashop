<?php
/*
 * 2007-2015 PrestaShop
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to http://www.prestashop.com for more information.
 *
 *  @author PrestaShop SA <contact@prestashop.com>
 *  @copyright  2007-2015 PrestaShop SA
 *  @license    http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 *  International Registered Trademark & Property of PrestaShop SA
 */
declare(strict_types=1);

require_once _PS_MODULE_DIR_ . 'checkoutklap/Model/KlapTransaction.php';
require_once(_PS_MODULE_DIR_ . 'checkoutklap/HelperPasarela.php');

class ToolsKlap
{
    protected $logger;
    protected $hp;
    protected $module;
    /**
     * ToolsKlap constructor.
     *
     * @param Module $module
     */
    public function __construct($module)
    {
        $this->module = $module;
        $this->hp = new HelperPasarela($this->module, 'MCP_');
        $this->logger = $this->hp->getLogger();
    }

    /**
   * Retorna la fecha formateada con zona horaria
   * @return String
   * 
   */
    public function getCurrentDateTime(): String
    {
        date_default_timezone_set('America/Santiago');
        return date('F j, Y, G:i:s') . ' ' . date_default_timezone_get();
    }

    /**
     * set the payment information on ps_order_payment
     *
     * @param int $cart_id
     * @param array $data
     * @return bool|null
     */
    public function setPaymentInformation(int $cart_id, array $data)
    {
        $cart = new Cart($cart_id);
        $customer = new Customer((int) $cart->id_customer);
        $order_id = Order::getIdByCartId($cart_id);
        if ($order_id == null) {
            return null;
        }
        $order = new Order($order_id);
        $orderReference = $order->reference;

        $lastDigits = isset($data['last_digits']) ? $data['last_digits'] : null;
        $brand = isset($data['brand']) ? $data['brand'] : null;
        $lastDigits = isset($data['last_digits']) ? '**** **** **** ' . $data['last_digits'] : null;
        $cardHolder = $customer->firstname && $customer->lastname ? $customer->firstname . ' ' . $customer->lastname : null;
        $authorizationCode = isset($data['approval_code']) ? $data['approval_code'] : null;

        $order_payment = $order->getOrderPaymentCollection();

        if (!empty($order_payment)) {
            $order_payment[0]->transaction_id = $authorizationCode;
            $order_payment[0]->card_number = $lastDigits;
            $order_payment[0]->card_brand = $brand;
            $order_payment[0]->card_holder = $cardHolder;
            $order_payment[0]->update();

            $this->logger->info('Informacion de guardada correctamente en ps_order_payment.');

            return true;
        }

        $this->logger->info('Error al guardada informacion en ps_order_payment.');
        
        return false;
    }

    /**
     * save klap transaction in the database
     *
     * @param int $cart_id
     * @param int $klap_id
     * @param int $order_id
     * @param array $data
     * @return KlapTransaction|null
     */
    public function saveTransacion(int $cart_id, string $klap_id, int $order_id, array $data): ?KlapTransaction
    {
        $cart = new Cart($cart_id);
        if ($cart->id == null) {
            return null; // No se puede crear la transacción si el carrito no existe
        }
        $customer = new Customer((int) $cart->id_customer);
        $mcCode = isset($data['mc_code']) ? $data['mc_code'] : null;
        $lastDigits = isset($data['last_digits']) ? $data['last_digits'] : null;
        $brand = isset($data['brand']) ? $data['brand'] : null;
        $lastDigits = isset($data['last_digits']) ? '**** **** **** ' . $data['last_digits'] : null;
        $cardLastDigits = isset($data['last_digits']) ? $data['last_digits'] : null;
        $cardHolder = $customer->firstname && $customer->lastname ? $customer->firstname . ' ' . $customer->lastname : null;
        $authorizationCode = isset($data['approval_code']) ? $data['approval_code'] : null;
        $installments = isset($data['quotas_number']) ? $data['quotas_number'] : null;
        
        if(isset($data['card_type'])){
          switch($data['card_type']){
            case 'CREDIT':
                $transactionType = 'CREDITO';
                break;
            case 'DEBIT':
                $transactionType = 'DEBITO';
                break;
            case 'PREPAID':
                $transactionType = 'PREPAGO';
                break;
            default:
              $transactionType = null;
          }
        }


        $amount = isset($data['amount']) ? $data['amount'] : null;

        $installmentsAmount = null;
        if ($amount && $installments && $transactionType == 'CREDITO') {
            $installmentsAmount = (string) number_format($amount / $installments, 2, '.', '');
            $this->logger->info('Monto de cada cuota: ' . $installmentsAmount);
        }   
                
        $transaction = new KlapTransaction();
        $transaction->cart_id = (int) $cart_id;
        $transaction->pedido_id = (int) $order_id;
        $transaction->order_id = $klap_id;
        $transaction->mc_code = $mcCode;
        $transaction->status = (int) KlapTransaction::STATUS_APPROVED;
        $transaction->klap_data = json_encode($data);
        $transaction->amount = $cart->getOrderTotal();
        $transaction->card_number = $lastDigits;
        $transaction->card_brand = $brand;
        $transaction->card_holder = $cardHolder;
        $transaction->card_last_digits = $cardLastDigits;
        $transaction->transaction_type = $transactionType;
        $transaction->installments = $installments;
        $transaction->installment_amount = $installmentsAmount;
        $transaction->authorization_code = $authorizationCode;
        $transaction->created_at = date('Y-m-d H:i:s');

        if ($transaction->save()) {
            return $transaction;
        } else {
            return null;
        }
    }

    /**
     * get the order by referenceId
     *
     * @param int $cart_id
     * @param int $amount
     * @return Order|null
     */
    public function getOrderByReference(int $cart_id, int $amount): ?Order
    {
        $order_id = Order::getIdByCartId($cart_id);
        if ($order_id) {
            $order = new Order($order_id);
        }else{
            $cart = new Cart($cart_id);
            $customer = new Customer((int) $cart->id_customer);
            $amountCart = intval(number_format($cart->getOrderTotal(true, Cart::BOTH), 0, ',', ''));
            $amountWebhook = isset($amount) ? intval(number_format($amount, 0, ',', '')) : null;
            
            if ($amountCart != $amountWebhook) {
                return null; // No se puede crear la orden si los montos no coinciden
            }else{
                $order = $this->createOrder((int) $cart->id, (int) $amountCart, $customer);
                if ($order == null) {
                    $order = Order::getIdByCartId($cart_id);
                }
            }
        }

        return $order;
    } 

    /**
     * create the order on PS
     *
     * @param int $cart_id
     * @param int $amount
     * @param object $customer
     * @return order
     */

    private function createOrder(int $cart_id, int $amount, object $customer): order
    {
        $this->module->validateOrder(
            (int) $cart_id,
            (int) $this->hp->getOrderStatusPaid(), 
            (float) $amount,
            $this->module->displayName,
            null,
            [],
            null,
            false,
            $customer->secure_key
        );
        $order = new Order((int) $this->module->currentOrder);
        
        return $order;
    }

}
