<?php
/*
 * 2007-2015 PrestaShop
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to http://www.prestashop.com for more information.
 *
 *  @author PrestaShop SA <contact@prestashop.com>
 *  @copyright  2007-2015 PrestaShop SA
 *  @license    http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 *  International Registered Trademark & Property of PrestaShop SA
 */
declare(strict_types=1);

require_once _PS_MODULE_DIR_ . 'checkoutklap/Model/KlapTransaction.php';
require_once(_PS_MODULE_DIR_ . 'checkoutklap/HelperPasarela.php');

// Marcelo Mallea - Se eliminar path src
require_once _PS_MODULE_DIR_ . 'checkoutklap/Classes/ToolsKlap.php';

use \Multicaja\Payments\Utils\ValidateParams;

class CheckoutKlapCallbackHandlerModuleFrontController extends ModuleFrontController
{
  protected $hp;
  protected $toolsKlap;
  protected $logger;
  const PARA_ORDEN = '] para la orden, referenceId: ';
  const ORDERLOG = ', orderId: ';
  const FECHA = ', fecha: ';

  /**
   * Metodo por defecto a implementar en los controladores de Prestashop
   */
  public function initContent()
  {
    $this->hp = new HelperPasarela($this->module, 'MCP_');
    $this->toolsKlap = new ToolsKlap($this->module);
    $this->ssl = true;
    $this->display_column_left = false;
    $this->logger = $this->hp->getLogger();
    $paymentDate = $this->toolsKlap->getCurrentDateTime();

    $callback = isset($_GET['mcb']) ? $_GET['mcb'] : null;
    //permite capturar la validación del webhook o url de redireccion invocada desde el administrador del plugin
    //se usa simplemente para verificr que se puede llegar a el
    $test_access = isset($_GET['test_access']) ? $_GET['test_access'] : null;

    if ($test_access === 'true') {
      if ($callback === 'return_url' || $callback === 'cancel_url') {
        echo 'La url de redireccion [' . $callback . '] funciona correctamente';
      } else {
        echo 'El webhook [' . $callback . '] funciona correctamente';
      }
      die();
    }

    //maneja el callback cuando se redirecciona desde el pasarela front a las url de la orden: return_url o cancel_url
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
      $referenceId = isset($_GET['referenceId']) ? $_GET['referenceId'] : null;
      $orderId = isset($_GET['orderId']) ? $_GET['orderId'] : '';

      $this->validateOrderGet((int) $referenceId, $orderId, $callback);
      parent::initContent(); //es necesario llamar al initContent del padre
    } else {
      try{
        if ($callback !== 'webhook_confirm' && $callback !== 'webhook_reject') {
          throw new InvalidArgumentException('Error en el nombre del webhook: ' . $callback);
        }

        //maneja el callback cuando se invoca desde pasarela a los webhooks de la orden: webhook_confirm o webhook_reject
        $rawPost = file_get_contents('php://input');
        $data = json_decode($rawPost, true);
        $this->logger->info('DATA WEBHOOK ' . json_encode($data));
        if ($data === null) {
          throw new InvalidArgumentException('Error al decodificar el JSON del webhook: '. $callback);
        }

        //validacion de los datos recibidos
        $orderId = isset($data['order_id']) ? $data['order_id'] : null;
        if ($orderId == null) {
          throw new InvalidArgumentException('Error en la invocación del webhook [' . $callback .'] orderId inválido');
        }

        $referenceId = isset($data['reference_id']) ? intval($data['reference_id']) : null;
        if ($referenceId == null) {
          throw new InvalidArgumentException('Error en la invocación del webhook [' . $callback . self::ORDERLOG . $orderId .'] referenceId inválido');
        }

        //verifica el apikey
        $apikey = $this->hp->getApiKey();
        $valid = ValidateParams::validateHashApiKeyFromHeaders(apache_request_headers(), $referenceId, $orderId, $apikey);
        if (!$valid) {
          throw new InvalidArgumentException('Error en la autenticación del webhook [' . $callback . self::PARA_ORDEN . $referenceId . self::ORDERLOG . $orderId . self::FECHA . $paymentDate);
        }

        if ($callback !== 'webhook_confirm' && $callback !== 'webhook_reject') {
          throw new InvalidArgumentException('Error en el nombre del webhook [' . $callback . self::PARA_ORDEN . $referenceId . self::ORDERLOG . $orderId);
        }

        if ($callback === 'webhook_confirm') {
          $this->validateOrderPost((int) $referenceId, $orderId, $data, $callback, $paymentDate);
        } else {
          $this->logger->error('Pago rechazado o anulado usando [Klap Checkout' . self::PARA_ORDEN . $referenceId . self::ORDERLOG . $orderId . self::FECHA . $paymentDate);
        }
        parent::initContent(); //es necesario llamar al initContent del padre
        header('HTTP/1.1 200 OK');
        die();

      } catch (Exception $ex) {
        $this->logger->error('Error CallbackHandler: ' . $ex->getMessage() . ' - ' . $ex->getLine() . ' - ' . $ex->getFile());
        $this->logger->error($ex->getMessage() . self::FECHA . $paymentDate, $ex);
        header('HTTP/1.1 500 Internal Server Error');
        die();

      }
    }
  }

  /**
   * validate the order when the user is redirected to return_url or cancel_url
   * @param int $referenceId
   * @param string $orderId
   * @param string $callback
   * @throws InvalidArgumentException
   * @throws Exception
   * @return void
   */
  private function validateOrderGet(? int $referenceId, ? string $orderId, ? string $callback)
  {
    // Pago anulado, pasarela redirecciona sin datos para identificar
    if ($referenceId == null || $orderId == null) {
      //$this->errors[] = $this->l('Error al procesar tu pago.');
      //Tools::redirect('index.php?controller=cart&action=show');
      return $this->displayError(
          $this->l('Error al procesar tu pago.'),
          $referenceId
        );
    }

    if ($callback !== 'return_url' && $callback !== 'cancel_url') {
      throw new InvalidArgumentException('Error en el nombre de la url de redirección [' . $callback . self::PARA_ORDEN . $referenceId . self::ORDERLOG . $orderId);
    }

    //es orden pagada

    $order_id = Order::getIdByCartId((int) $referenceId);
    if ($order_id) {
      $order = new Order((int) $order_id);
    } else {
      $this->logger->info('ERROR EN PAGO, ORDER NO EXISTE EN PS, REFERENCE_ID ' . $referenceId);
      //Tools::redirect('index.php?controller=cart&action=show');
      return $this->displayError(
        $this->l('Error al procesar tu pago.'),
        $referenceId
      );
    }

    if ($order->id) {
      $orderStatus = $order->getCurrentState();
      $customer = new Customer((int) $order->id_customer);
    }

    if ($orderStatus != null && $this->hp->compareStatus($orderStatus, $this->hp->getOrderStatusPaid())){
      $this->logger->info('ESTATUS DE PAGO ' . $orderStatus . ', CON REFERENCE_ID= ' . $referenceId . ', ORDER_ID= ' . $orderId);
      Tools::redirect($this->context->link->getPageLink(
          'order-confirmation',
          true,
          (int) $this->context->language->id,
          [
              'id_cart' => (int) $order->id_cart,
              'id_module' => (int) $this->module->id,
              'id_order' => (int) $order->id,
              'key' => $customer->secure_key,
          ]
      ));
    }
  }

  /**
   * validate the order when the user is redirected to return_url or cancel_url
   * @param int $referenceId
   * @param string $orderId
   * @param array $data
   * @param string $callback
   * @param string $paymentDate
   * @throws InvalidArgumentException
   * @throws Exception
   * @return bool
   */
  private function validateOrderPost(int $referenceId, string $orderId, array $data, string $callback, string $paymentDate)
  {
    $order = $this->toolsKlap->getOrderByReference((int) $referenceId, (int) round($data['amount'], 0));
    if ($order == null) {
      throw new InvalidArgumentException('Error: Monto invalido ' . $callback . self::PARA_ORDEN . $referenceId . self::ORDERLOG . $orderId);
    }

    $response = $this->toolsKlap->setPaymentInformation($referenceId, $data);
    if ($response == false || $response == null) {
      throw new InvalidArgumentException('Error al guardar la información de pago en ps_order_payment');
    }

    $transaction = $this->toolsKlap->saveTransacion((int) $referenceId, $orderId, (int) $order->id, $data);
    if ($transaction == null) {
      throw new InvalidArgumentException('Error al guardar la transacción en la base de datos');
    }

    $this->logger->info('Pago realizado con exito usando Klap Checkout' . self::PARA_ORDEN . $referenceId . self::ORDERLOG . $orderId . self::FECHA . $paymentDate);

    return true;
  }

  /**
     * Display error message
     *
     * @param string $message
     */

    protected function displayError(string $message, int $referenceId)
    {
        $this->context->smarty->assign([
          'message' => $message,
          'referenceId' => $referenceId,
        ]);

        return $this->setTemplate('module:checkoutklap/views/templates/front/payment_error.tpl');
    }
}
