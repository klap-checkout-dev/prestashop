<?php

class OrderPaymentOne extends OrderPaymentCore
{
  /** @var string */
  public $card_last_digits;
  public $transaction_type;
  public $installments;
  public $installment_amount;
  public $authorization_code;


  public static $definition = array(
    'table' => 'order_payment',
    'primary' => 'id_order_payment',
    'fields' => array(
      'transaction_id' => array('type' => self::TYPE_STRING, 'validate' => 'isString'),
      'card_number' => array('type' => self::TYPE_STRING, 'validate' => 'isString'),
      'card_brand' => array('type' => self::TYPE_STRING, 'validate' => 'isString'),
      'card_holder' => array('type' => self::TYPE_STRING, 'validate' => 'isString'),
      'card_last_digits' => array('type' => self::TYPE_STRING, 'validate' => 'isString'),
      'transaction_type' => array('type' => self::TYPE_STRING, 'validate' => 'isString'),
      'installments' => array('type' => self::TYPE_STRING, 'validate' => 'isString'),
      'installment_amount' => array('type' => self::TYPE_STRING, 'validate' => 'isString'),
      'authorization_code' => array('type' => self::TYPE_STRING, 'validate' => 'isString'),
    ),
  );

  public static function updatePaymentByReference($orderReference, $newData)
  {
    if (!$orderReference || empty($newData)) {
      return false;
    }

    $fields = [];
    foreach ($newData as $key => $value) {
      $fields[] = "`$key` = '" . pSQL($value) . "'";
    }

    $sql = 'UPDATE ' . _DB_PREFIX_ . 'order_payment
            SET ' . implode(', ', $fields) . '
            WHERE order_reference = "' . pSQL($orderReference) . '"';

    return Db::getInstance()->execute($sql);
  }
}
