<?php

namespace PrestaShop\Module\Klap\Install;

use Db;

class KlapInstaller
{
    public function installKlapTransactionTable()
    {
        return Db::getInstance()->execute('CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'klap_transaction` (
                `id` bigint(20) NOT NULL AUTO_INCREMENT,
                `cart_id` varchar(100) NOT NULL UNIQUE,
                `pedido_id` varchar(100),
                `mc_code` varchar(100),
                `order_id` varchar(100),
                `amount` bigint(20) NOT NULL,
                `status` tinyint(3) NOT NULL,
                `klap_data` TEXT,
                `created_at` TIMESTAMP NOT NULL DEFAULT NOW(),
                 PRIMARY KEY (id)) ENGINE='._MYSQL_ENGINE_.' DEFAULT CHARSET=utf8;');
    }
}
