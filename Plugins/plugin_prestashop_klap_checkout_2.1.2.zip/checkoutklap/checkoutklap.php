<?php
if (!defined('_PS_VERSION_')) {
  exit;
}

define('MCP_PLUGIN_VERSION', '2.1.2');

require_once(_PS_MODULE_DIR_ . 'checkoutklap/HelperPasarela.php');
require_once(_PS_MODULE_DIR_ . 'checkoutklap/MulticajaUtils.php');
require_once(_PS_MODULE_DIR_ . 'checkoutklap/Install/KlapInstaller.php');
require_once _PS_MODULE_DIR_ . 'checkoutklap/Model/KlapTransaction.php';

// carga el sdk de Klap Checkouts
require_once(_PS_MODULE_DIR_ . 'checkoutklap/sdk/src/init.php');

use \Multicaja\Payments\Utils\PaymentsApiClient;
use \Multicaja\Payments\Model\MerchantMethodsResponse;
use \PrestaShop\Module\Klap\Install\KlapInstaller;

/**
 * Plugin de Klap Checkout
 *
 * docs: http://doc.prestashop.com/pages/viewpage.action?pageId=51184607
 */
class CheckoutKlap extends PaymentModule
{

  private $hp;
  private $logger = null;
  private $merchantMethods;

  public static $METHOD_SODEXO = 'sodexo';
  public static $METHOD_EFECTIVO = 'efectivo';
  public static $METHOD_TARJETAS = 'tarjetas';
  public static $METHOD_TRANSFERENCIA = 'transferencia';
  const CHECKOUTKLAP = 'checkoutklap';
  const CREATEORDERCARD = 'CreateOrderCard';
  const CREATEORDERSODEXO = 'CreateOrderSodexo';
  const CREATEORDERCASHTEF = 'CreateOrderCashTef';
  const PAGATARJETAS = 'Paga aquí con tarjetas y billeteras';
  const PAGAEFECTIVOTRANSFERENCIAS = 'Pago con efectivo y/o transferencia';
  const PAGASODEXO = 'Pago con tarjeta Sodexo';
  const LOGO = 'logo';
  const TITLE = 'title';
  const CONTROLLER = 'controller';
  const ID_OPTION = 'id_option';
  const SELECT = 'select';
  const REQUIRED = 'required';
  const LABEL = 'label';
  const OPTIONS = 'options';
  const QUERY = 'query';
  const COL = 'col';
  const TYPE = 'type';
  const NAME = 'name';
  const DESC = 'desc';
  const ID = 'id';
  const TABLE_NAME = 'klap_transaction';

  /**
   * Devuelve informacion propia del ecommerce, usado por HelperPasarela
   */
  public function getEcommerceData()
  {
    return array(
      'pluginVersion' => MCP_PLUGIN_VERSION,
      'ecommerceInfo' => 'prestashop-' . _PS_VERSION_,
      'webhooksBaseUrl' => Context::getContext()->link->getModuleLink(self::CHECKOUTKLAP, 'CallbackHandler'),
      'orderStatusPendingPayment' => Configuration::get('PS_OS_BANKWIRE'),
      'orderStatusPaid' => Configuration::get('PS_OS_PAYMENT'),
      'orderStatusFailed' => Configuration::get('PS_OS_ERROR')
    );
  }

  /**
   * Devuelve un valor de una configuracion, usado por HelperPasarela
   */
  public function getConfigValue($key, $defaultValue)
  {
    $value = Configuration::get($key, $defaultValue);
    return $value == '' || $value == null ? $defaultValue : $value;
  }

  public function __construct()
  {

    $this->name = self::CHECKOUTKLAP;
    $this->tab = 'payments_gateways';
    $this->version = MCP_PLUGIN_VERSION;
    $this->author = 'Klap';
    $this->need_instance = 0;
    $this->bootstrap = true;
    $this->controllers = array(self::CREATEORDERCARD, self::CREATEORDERSODEXO, self::CREATEORDERCASHTEF, 'CallbackHandler');

    $this->hp = new HelperPasarela($this, 'MCP_');
    $this->logger = $this->hp->getLogger();

    parent::__construct();

    $this->displayName = 'Klap Checkout (' . $this->version . ')';
    $this->description = 'Paga con Klap Checkout. Podrás comprar con tarjetas, sodexo, efectivo o transferencia bancaria.';
    $this->limited_currencies = array('CLP');
    $this->ps_versions_compliancy = array('min' => '1.6', 'max' => _PS_VERSION_);
  }

  public function install()
  {

    $displayOrder = $this->getDisplayOrderHookName();
    $this->postProcess();
    $this->installKlapTable();
    // Llamar al método para agregar la columna si no existe
    $this->addColumnTableOrderPayment();
    return parent::install() &&
      $this->registerHook('header') &&
      $this->registerHook('payment') && //hook: Muestra el boton de pago en prestashop = 1.6
      $this->registerHook('paymentOptions') && //hook: Muestra el boton de pago en prestashop >= 1.7
      $this->registerHook('paymentReturn') &&
      $this->registerHook('displayPaymentReturn') &&
      $this->registerHook('displayAdminOrderLeft') &&
      $this->registerHook($displayOrder);

  }

  private function addColumnTableOrderPayment()
  {
    $this->addCardLastDigitsColumn();
    $this->addInstallmentsAmountColumn();
    $this->addInstallmentsColumn();
    $this->addAuthorizationCodeColumn();
    $this->addTransactionTypeColumn();
  }

  /**
   * Método genérico para agregar una columna a la tabla `order_payment` si no existe.
   *
   * @param string $columnName Nombre de la columna.
   * @param string $columnDefinition Definición de la columna (tipo, tamaño, valor predeterminado, etc.).
   */
  private function addColumnIfNotExists($columnName, $columnDefinition)
  {
    // Verificar si la columna ya existe
    $sqlCheck = "SHOW COLUMNS FROM `" . _DB_PREFIX_ . "order_payment` LIKE '$columnName'";
    $columnExists = Db::getInstance()->executeS($sqlCheck);

    if (empty($columnExists)) {
      // Si la columna no existe, agregarla
      $sql = "ALTER TABLE `" . _DB_PREFIX_ . "order_payment`
                ADD COLUMN `$columnName` $columnDefinition";
      if (!Db::getInstance()->execute($sql)) {
        $this->logger->info("Error al agregar la columna $columnName a la tabla order_payment.");
      } else {
        $this->logger->info("Columna $columnName agregada correctamente.");
      }
    } else {
      $this->logger->info("Columna: $columnName ya existe en ps_order_payment.");
    }
  }

  /**
   * Métodos específicos que utilizan el método genérico para agregar columnas.
   */
  private function addCardLastDigitsColumn()
  {
    $this->addColumnIfNotExists('card_last_digits', "VARCHAR(10) DEFAULT NULL");
  }

  private function addTransactionTypeColumn()
  {
    $this->addColumnIfNotExists('transaction_type', "VARCHAR(50) DEFAULT NULL");
  }

  private function addInstallmentsColumn()
  {
    $this->addColumnIfNotExists('installments', "VARCHAR(10) DEFAULT NULL");
  }

  private function addInstallmentsAmountColumn()
  {
    $this->addColumnIfNotExists('installment_amount', "VARCHAR(254) DEFAULT NULL");
  }

  private function addAuthorizationCodeColumn()
  {
    $this->addColumnIfNotExists('authorization_code', "VARCHAR(10) DEFAULT NULL");
  }



  public function uninstall()
  {
    return parent::uninstall();
  }

  /**
   * Add the CSS & JavaScript files you want to be added on the FO.
   */
  public function hookHeader()
  {
  }

  protected function installKlapTable()
  {
    $installer = new KlapInstaller();
    $installer->installKlapTransactionTable();
  }


  /**
   * Muestra el boton de pago en prestashop = 1.6
   */
  public function hookPayment($params)
  {
    $isEnabledAndConfigured = $this->hp->isEnabledAndConfigured();
    if (!$this->active || !$isEnabledAndConfigured) {
      return false;
    }

    $isActivatedCard = false;
    $isActivatedCashTef = false;
    $isActivatedSodexo = false;
    try {
      $this->merchantMethods = $this->getMerchantActivedMethods($this->hp->getEnvironment(), $this->hp->getApiKey(), $this->hp->getLogger());

      if ($this->isActivedMethod(self::$METHOD_TARJETAS)) {
        $isActivatedCard = true;
      }
      if ($this->isActivedMethod(self::$METHOD_EFECTIVO) || $this->isActivedMethod(self::$METHOD_TRANSFERENCIA)) {
        $isActivatedCashTef = true;
      }
      if ($this->isActivedMethod(self::$METHOD_SODEXO)) {
        $isActivatedSodexo = true;
      }
    } catch (Exception $ex) {
      $this->logger->error('Error al obtener los metodos activos del comercio: ' . $ex->getMessage());
    }

    // Tarjetas
    $controllerFrontCard = $this->context->link->getModuleLink(self::CHECKOUTKLAP, self::CREATEORDERCARD);
    $this->context->smarty->assign(array(
      'isActivatedCard' => $isActivatedCard,
      'logoCard' => Media::getMediaPath(_PS_MODULE_DIR_ . $this->name . '/public/images/ps_16/klap-flex.png'),
      'titleCard' => self::PAGATARJETAS,
      'controllerCard' => $controllerFrontCard
    ));

    // Efectivo y Tranferencias
    $controllerFrontCashTef = $this->context->link->getModuleLink(self::CHECKOUTKLAP, self::CREATEORDERCASHTEF);
    $this->context->smarty->assign(array(
      'isActivatedCashTef' => $isActivatedCashTef,
      'logoCashTef' => Media::getMediaPath(_PS_MODULE_DIR_ . $this->name . '/public/images/ps_16/klap_logo.png'),
      'titleCashTef' => self::PAGAEFECTIVOTRANSFERENCIAS,
      'controllerCashTef' => $controllerFrontCashTef
    ));

    // Sodexo
    $controllerFrontSodexo = $this->context->link->getModuleLink(self::CHECKOUTKLAP, self::CREATEORDERSODEXO);
    $this->context->smarty->assign(array(
      'isActivatedSodexo' => $isActivatedSodexo,
      'logoSodexo' => Media::getMediaPath(_PS_MODULE_DIR_ . $this->name . '/public/images/ps_16/sodexo_logo.png'),
      'titleSodexo' => self::PAGASODEXO,
      'controllerSodexo' => $controllerFrontSodexo
    ));

    return $this->display(__FILE__, 'views/templates/hook/payment_button_16.tpl');
  }

  /**
   * Muestra el boton de pago en prestashop >= 1.7
   */
  public function hookPaymentOptions($params)
  {
    $isEnabledAndConfigured = $this->hp->isEnabledAndConfigured();
    if (!$this->active || !$isEnabledAndConfigured) {
      return false;
    }

    $controllerFrontCard = $this->context->link->getModuleLink(self::CHECKOUTKLAP, self::CREATEORDERCARD);
    $this->context->smarty->assign(array(
      self::LOGO => '',
      self::TITLE => self::PAGATARJETAS,
      self::CONTROLLER => $controllerFrontCard
    ));

    $controllerFrontCashTef = $this->context->link->getModuleLink(self::CHECKOUTKLAP, self::CREATEORDERCASHTEF);
    $this->context->smarty->assign(array(
      self::LOGO => '',
      self::TITLE => self::PAGAEFECTIVOTRANSFERENCIAS,
      self::CONTROLLER => $controllerFrontCashTef
    ));

    $controllerFrontSodexo = $this->context->link->getModuleLink(self::CHECKOUTKLAP, self::CREATEORDERSODEXO);
    $this->context->smarty->assign(array(
      self::LOGO => '',
      self::TITLE => self::PAGASODEXO,
      self::CONTROLLER => $controllerFrontSodexo
    ));

    $paymentForm = $this->fetch('module:checkoutklap/views/templates/hook/payment_button.tpl');

    $paymentOptionCard = new PrestaShop\PrestaShop\Core\Payment\PaymentOption();
    $paymentOptionCard->setCallToActionText(self::PAGATARJETAS)
      ->setModuleName('Klap Checkout Tarjetas')
      ->setLogo(Media::getMediaPath(_PS_MODULE_DIR_ . $this->name . '/public/images/ps_17/klap-flex.svg'))
      ->setAction($controllerFrontCard)
      ->setForm($paymentForm);

    $paymentOptionCashTef = new PrestaShop\PrestaShop\Core\Payment\PaymentOption();
    $paymentOptionCashTef->setCallToActionText(self::PAGAEFECTIVOTRANSFERENCIAS)
      ->setModuleName('Klap Checkout Efectivo y/o Transferencias')
      ->setAdditionalInformation('<p>Paga en efectivo en comercios Klap, Caja Los Héroes, Tur Bus o Starken. O puedes transferir desde tu cuenta bancaria.</p>')
      ->setLogo(Media::getMediaPath(_PS_MODULE_DIR_ . $this->name . '/public/images/ps_17/logo-klap.svg'))
      ->setAction($controllerFrontCashTef)
      ->setForm($paymentForm);

    $paymentOptionSodexo = new PrestaShop\PrestaShop\Core\Payment\PaymentOption();
    $paymentOptionSodexo->setCallToActionText(self::PAGASODEXO)
      ->setModuleName('Klap Checkout Sodexo')
      ->setAdditionalInformation('<p>Paga con tu rut y clave dinámica.</p>')
      ->setLogo(Media::getMediaPath(_PS_MODULE_DIR_ . $this->name . '/public/images/ps_17/logo-sodexo.svg'))
      ->setAction($controllerFrontSodexo)
      ->setForm($paymentForm);

    $paymentOptions = array();

    try {
      $this->merchantMethods = $this->getMerchantActivedMethods($this->hp->getEnvironment(), $this->hp->getApiKey(), $this->hp->getLogger());

      if ($this->isActivedMethod(self::$METHOD_TARJETAS)) {
        array_push($paymentOptions, $paymentOptionCard);
      }
      if ($this->isActivedMethod(self::$METHOD_EFECTIVO) || $this->isActivedMethod(self::$METHOD_TRANSFERENCIA)) {
        array_push($paymentOptions, $paymentOptionCashTef);
      }
      if ($this->isActivedMethod(self::$METHOD_SODEXO)) {
        array_push($paymentOptions, $paymentOptionSodexo);
      }
    } catch (Exception $ex) {
      $this->logger->error('Error al obtener los metodos activos del comercio: ' . $ex->getMessage());
    }

    return $paymentOptions;
  }

  /**
   * This hook is used to display the order confirmation page.
   */
  public function hookPaymentReturn($params)
  {

    $nameOrderRef = isset($params['order']) ? 'order' : 'objOrder';
    $order = $params[$nameOrderRef];
    $cart = new Cart($order->id_cart);
    $orderId = "pending";
    $orderEcommerce = "";
    try {
      $orderEcommerce = new Order(Order::getOrderByCartId($order->id_cart));
      $payment = $order->getOrderPaymentCollection();
      $orderId = $payment[0]->transaction_id; //order Klap
    } catch (Exception $ex) {
      $this->logger->error('Error en hookPaymentReturn: ' . $ex->getMessage());
    }


    $orderStatus = $order->getCurrentOrderState()->id;

    //por defecto es orden con error
    $orderStatusName = 'failed';

    //es orden pendiente de pago
    if ($this->hp->compareStatus($orderStatus, $this->hp->getOrderStatusPendingPayment())) {
      $orderStatusName = 'pending';
      //es orden pagada
    } else if ($this->hp->compareStatus($orderStatus, $this->hp->getOrderStatusPaid())) {
      $orderStatusName = 'paid';
    }

    $refreshUrl = $this->hp->getReturnUrl() . '&referenceId=' . $order->id_cart . '&orderId=' . $orderId;

    $contactUrl = $this->context->link->getPageLink('contact', true);

    $this->smarty->assign(array(
      'amount' => intval(round(number_format($cart->getOrderTotal(true, Cart::BOTH), 0, ',', ''))),
      'paymentMethod' => 'Klap Checkout',
      'paymentDate' => $orderEcommerce == "" ? "" : $orderEcommerce->date_upd,
      'orderId' => $orderId,
      'psReferenceId' => $order->reference,
      'orderStatusName' => $orderStatusName,
      'contactUrl' => $contactUrl,
      'refreshUrl' => $refreshUrl
    ));

    return $this->display(__FILE__, 'views/templates/hook/confirmation.tpl');
  }

  /**
   * ---------------------------------------------------------------
   * Seccion de administracion
   * ---------------------------------------------------------------
   */

  /**
   * Load the configuration form
   */
  public function getContent()
  {
    /**
     * If values have been submitted in the form, process.
     */
    if ((bool) Tools::isSubmit('submitMulticajaPasarela')) {
      $this->postProcess();
    }
    $debugDataHtml = $this->hp->getDebugDataHtml();
    return $this->renderForm() . $debugDataHtml;
  }

  /**
   * Create the form that will be displayed in the configuration of your module.
   */
  protected function renderForm()
  {

    $status = array(
      array(
        self::ID_OPTION => Configuration::get('PS_OS_BANKWIRE'),
        self::NAME => 'Pendiente de pago'
      ),
      array(
        self::ID_OPTION => Configuration::get('PS_OS_PAYMENT'),
        self::NAME => 'Pago aceptado'
      ),
      array(
        self::ID_OPTION => Configuration::get('PS_OS_ERROR'),
        self::NAME => 'Error de pago'
      ),
      array(
        self::ID_OPTION => Configuration::get('PS_OS_CANCELED'),
        self::NAME => 'Cancelado'
      )
    );

    $efectivoNotifiacionEmail = array(
      array(
        self::ID_OPTION => 'true',
        self::NAME => 'Klap Checkout'
      ),
      array(
        self::ID_OPTION => 'false',
        self::NAME => 'Comercio'
      )
    );

    $environments = array(
      array(
        self::ID_OPTION => 'integration',
        self::NAME => 'Integración'
      ),
      array(
        self::ID_OPTION => 'production',
        self::NAME => 'Producción'
      )
    );

    if ($this->hp->isLocalDev()) {
      $local = array(
        array(
          self::ID_OPTION => 'local',
          self::NAME => 'Local'
        )
      );
      $environments = array_merge($local, $environments);
    }

    $enable = array(
      array(
        self::COL => 5,
        self::TYPE => self::SELECT,
        self::REQUIRED => true,
        self::NAME => 'MCP_ENABLE',
        self::LABEL => 'Activa/Desactiva',
        self::OPTIONS => array(
          self::QUERY => array(
            array(
              self::ID_OPTION => 'true',
              self::NAME => 'Activa'
            ),
            array(
              self::ID_OPTION => 'false',
              self::NAME => 'Desactiva'
            )
          ),
          self::ID => self::ID_OPTION,
          self::NAME => self::NAME
        )
      )
    );

    $inputs = array(
      array(
        self::COL => 5,
        self::TYPE => 'text',
        self::REQUIRED => true,
        self::NAME => 'MCP_APIKEY_INTEGRATION',
        self::LABEL => 'ApiKey Integración'
      ),
      array(
        self::COL => 5,
        self::TYPE => 'text',
        self::REQUIRED => true,
        self::NAME => 'MCP_APIKEY_PRODUCTION',
        self::LABEL => 'ApiKey Producción'
      ),
      array(
        self::COL => 5,
        self::TYPE => self::SELECT,
        self::REQUIRED => true,
        self::NAME => 'MCP_ENVIRONMENT',
        self::LABEL => 'Ambiente',
        self::OPTIONS => array(
          self::QUERY => $environments,
          self::ID => self::ID_OPTION,
          self::NAME => self::NAME
        )
      ),
      array(
        self::COL => 5,
        self::TYPE => self::SELECT,
        self::REQUIRED => true,
        self::NAME => 'MCP_STATUS_PENDIG_PAYMENT',
        self::LABEL => 'Estado de orden por pagar',
        self::OPTIONS => array(
          self::QUERY => $status,
          self::ID => self::ID_OPTION,
          self::NAME => self::NAME
        )
      ),
      array(
        self::COL => 5,
        self::TYPE => self::SELECT,
        self::REQUIRED => true,
        self::NAME => 'MCP_STATUS_PAID',
        self::LABEL => 'Estado de orden pagada exitosamente',
        self::OPTIONS => array(
          self::QUERY => $status,
          self::ID => self::ID_OPTION,
          self::NAME => self::NAME
        )
      ),
      array(
        self::COL => 5,
        self::TYPE => self::SELECT,
        self::REQUIRED => true,
        self::NAME => 'MCP_STATUS_FAILED',
        self::LABEL => 'Estado de orden con error en el pago',
        self::OPTIONS => array(
          self::QUERY => $status,
          self::ID => self::ID_OPTION,
          self::NAME => self::NAME
        )
      ),
      array(
        self::COL => 5,
        self::TYPE => 'text',
        self::REQUIRED => true,
        self::NAME => 'MCP_EFECTIVO_EXPIRATION_MINUTES',
        self::LABEL => 'Tiempo de expiración del cupón de pago',
        self::DESC => 'En cuantos minutos deseas que expire el cupón de efectivo? (-1 un día completo)'
      ),
      array(
        self::COL => 5,
        self::TYPE => 'text',
        self::REQUIRED => true,
        self::NAME => 'MCP_TRANSFERENCIA_EXPIRATION_MINUTES',
        self::LABEL => 'Tiempo de expiración de pago con transferencia',
        self::DESC => 'En cuantos minutos deseas esperar a que te transfieran por TEF? (-1 un día completo)'
      ),
      array(
        self::COL => '5',
        self::TYPE => 'text',
        self::REQUIRED => true,
        self::NAME => 'MCP_TARJETAS_EXPIRATION_MINUTES',
        self::LABEL => 'Tiempo de expiración de pago con tarjetas',
        self::DESC => 'En cuantos minutos deseas esperar a que te paguen con tarjetas? (-1 un día completo)'
      ),
      array(
        self::COL => '5',
        self::TYPE => 'text',
        self::REQUIRED => true,
        self::NAME => 'MCP_SODEXO_EXPIRATION_MINUTES',
        self::LABEL => 'Tiempo de expiración de pago con sodexo',
        self::DESC => 'En cuantos minutos deseas esperar a que te paguen con sodexo? (-1 un día completo)'
      ),
      array(
        self::COL => 5,
        self::TYPE => self::SELECT,
        self::REQUIRED => true,
        self::NAME => 'MCP_PAYMENTS_NOTIFY_USER',
        self::LABEL => 'Notificación de email efectivo',
        self::DESC => 'Quién envía email de cupón de efectivo?',
        self::OPTIONS => array(
          self::QUERY => $efectivoNotifiacionEmail,
          self::ID => self::ID_OPTION,
          self::NAME => self::NAME
        )
      ),
      array(
        self::COL => 5,
        self::TYPE => 'text',
        self::REQUIRED => false,
        self::NAME => 'MCP_LOGO_URL',
        self::LABEL => 'Url Logo',
        self::DESC => 'Url del logo del comercio'
      ),
      array(
        self::COL => 5,
        self::TYPE => 'text',
        self::REQUIRED => true,
        self::NAME => 'MCP_WEBHOOKS_DOMAIN',
        self::LABEL => 'Dominio de webhooks y redirección'
      )
    );

    if ($this->hp->isLocalDev()) {
      $apiKeyLocal = array(
        array(
          self::COL => 5,
          self::TYPE => 'text',
          self::REQUIRED => true,
          self::NAME => 'MCP_APIKEY_LOCAL',
          self::LABEL => 'ApiKey Local'
        )
      );
      $inputs = array_merge($apiKeyLocal, $inputs);
    }

    $fieldsForm = array(
      'form' => array(
        'legend' => array(
          self::TITLE => 'Configuración',
          'icon' => 'icon-cogs',
        ),
        'input' => array_merge($enable, $inputs),
        'submit' => array(
          self::TITLE => 'Guardar'
        )
      )
    );

    $helper = new HelperForm();

    $helper->show_toolbar = false;
    $helper->table = $this->table;
    $helper->module = $this;
    $helper->default_form_language = $this->context->language->id;
    $helper->allow_employee_form_lang = Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG', 0);
    $helper->identifier = $this->identifier;
    $helper->submit_action = 'submitMulticajaPasarela';
    $helper->currentIndex = $this->context->link->getAdminLink('AdminModules', false)
      . '&configure=' . $this->name . '&tab_module=' . $this->tab . '&module_name=' . $this->name;
    $helper->token = Tools::getAdminTokenLite('AdminModules');

    $helper->tpl_vars = array(
      'fields_value' => $this->getConfigFormValues(),
      'languages' => $this->context->controller->getLanguages(),
      'id_language' => $this->context->language->id
    );

    return $helper->generateForm(array($fieldsForm));
  }

  /**
   * Set values for the inputs.
   */
  protected function getConfigFormValues()
  {
    return array(
      'MCP_ENABLE' => $this->hp->getEnable(),
      'MCP_APIKEY_LOCAL' => $this->hp->getApiKeyLocal(),
      'MCP_APIKEY_INTEGRATION' => $this->hp->getApiKeyIntegration(),
      'MCP_APIKEY_PRODUCTION' => $this->hp->getApiKeyProduction(),
      'MCP_ENVIRONMENT' => $this->hp->getEnvironment(),
      'MCP_STATUS_PENDIG_PAYMENT' => $this->hp->getOrderStatusPendingPayment(),
      'MCP_STATUS_PAID' => $this->hp->getOrderStatusPaid(),
      'MCP_STATUS_FAILED' => $this->hp->getOrderStatusFailed(),
      'MCP_EFECTIVO_EXPIRATION_MINUTES' => $this->hp->getEfectivoExpirationMinutes(),
      'MCP_TRANSFERENCIA_EXPIRATION_MINUTES' => $this->hp->getTransferenciaExpirationMinutes(),
      'MCP_TARJETAS_EXPIRATION_MINUTES' => $this->hp->getTarjetasExpirationMinutes(),
      'MCP_SODEXO_EXPIRATION_MINUTES' => $this->hp->getSodexoExpirationMinutes(),
      'MCP_PAYMENTS_NOTIFY_USER' => $this->hp->getPaymentsNotifyUser(),
      'MCP_LOGO_URL' => $this->hp->getLogoUrl(),
      'MCP_WEBHOOKS_DOMAIN' => $this->hp->getWebhooksDomain()
    );
  }

  /**
   * Save form data.
   */
  protected function postProcess()
  {
    $formValues = $this->getConfigFormValues();
    foreach (array_keys($formValues) as $key) {
      Configuration::updateValue($key, trim(Tools::getValue($key)));
    }
  }

  /**
   * Metodo que permite obtener los metodos activos del comercio.
   */
  public function getMerchantActivedMethods($environment, $apikey, $logger)
  {
    try {
      PaymentsApiClient::setLogger($logger);
      $response = PaymentsApiClient::getMerchantActivedMethods($environment, $apikey);
    } catch (Exception $ex) {
      throw new Error('Error al obtener los metodos activos del comercio');
    }

    if ($response == null) {
      throw new InvalidArgumentException('Error al intentar conectar con Klap Checkout, sin respuesta. Por favor intenta más tarde.');
    }

    if (!($response instanceof MerchantMethodsResponse)) {
      $logger->error(json_encode($response));
      throw new InvalidArgumentException('Error en la respuesta de Klap Checkout. Por favor intenta más tarde.');
    }

    if ($response->getMethods() == null) {
      throw new InvalidArgumentException('Error al intentar conectar con Klap Checkout. Por favor intenta más tarde.');
    }

    return $response->getMethods();
  }

  /**
   * Metodo que permite determinar si un metodo esta presente dentro de los metodos activos del comercio.
   */
  private function isActivedMethod($method)
  {
    $isActived = false;
    if (in_array($method, $this->merchantMethods)) {
      $isActived = true;
    }
    return $isActived;
  }


  public function adminKlap($params)
  {
    if (!$this->active) {
      return null;
    }
    $pedidoId = $params['id_order'];
    $sql = 'SELECT * FROM ' . _DB_PREFIX_ . self::TABLE_NAME . ' WHERE `pedido_id` = "' . $pedidoId . '"';
    $transaction = \Db::getInstance()->getRow($sql);
    $this->logger->info("Admin Klap: " . $sql . " - " . json_encode($transaction));
    if (!$transaction) {
      return null;
    }
    $transactionKlap = new KlapTransaction($transaction['id']);
    $klapResponse = json_decode($transactionKlap->klap_data, true);
    $transactionDate = strtotime($transaction['created_at']);
    $isTarjeta = $klapResponse['card_type'] != null;
    $mcCode = $transaction['mc_code'];
    $amount = $transaction['amount'];
    $orderKlap = $transaction['order_id'];
    $details = array(
      array(
        'desc' => $this->l('Order ID Klap Checkout'),
        'data' => $orderKlap,
      ),
      array(
        'desc' => $this->l('Mc Code'),
        'data' => $mcCode,
      ),
      array(
        'desc' => $this->l('Monto transacción'),
        'data' => "$" . $amount,
      ),
      array(
        'desc' => $this->l('Fecha de Transacción'),
        'data' => $transactionDate != null ? date("d-m-Y", $transactionDate) . " " . date("H:i", $transactionDate) : "",
      ),
    );

    if ($isTarjeta) {
      $last_digits = $klapResponse['last_digits'];
      $brand = $klapResponse['brand'];
      $bin = $klapResponse['bin'];
      $cartType = $klapResponse['card_type'] == "DEBIT" ? "DÉBITO" : "CRÉDITO";
      array_push(
        $details,
        array(
          'desc' => $this->l('Tarjeta'),
          'data' => $bin . "******" . $last_digits,
        )
      );
      array_push(
        $details,
        array(
          'desc' => $this->l('Tipo de tarjeta'),
          'data' => $cartType,
        )
      );
      array_push(
        $details,
        array(
          'desc' => $this->l('Marca Tarjeta'),
          'data' => $brand,
        )
      );

      if ($cartType == "CRÉDITO") {
        $quotas_type = $klapResponse['quotas_type'] == "MERCHANT" ? "COMERCIO" : "EMISOR";
        $quotas_number = $klapResponse['quotas_number'];
        array_push(
          $details,
          array(
            'desc' => $this->l('Tipo de cuotas'),
            'data' => "CUOTAS " . $quotas_type,
          )
        );
        array_push(
          $details,
          array(
            'desc' => $this->l('Cantidad cuotas'),
            'data' => $quotas_number,
          )
        );
      }

    }
    $this->context->smarty->assign($this->name, array(
      '_path' => $this->_path,
      'title' => "Detalle de Pago Klap",
      'details' => $details,
    ));
    return $this->display(__FILE__, 'views/templates/admin/admin_klap.tpl');
  }

  public function hookdisplayAdminOrderLeft($params)
  {
    return $this->adminKlap($params);
  }
  public function hookdisplayAdminOrderTabContent($params)
  {
    return $this->adminKlap($params);
  }

  public function getDisplayOrderHookName()
  {
    $displayOrder = 'displayAdminOrderLeft';
    if (version_compare(_PS_VERSION_, '1.7.7.0', '>=')) {
      $displayOrder = 'displayAdminOrderTabContent';
    }
    return $displayOrder;
  }

}
