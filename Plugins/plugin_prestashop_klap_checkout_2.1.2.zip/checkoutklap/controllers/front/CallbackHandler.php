<?php

require_once(__DIR__ . '/BaseController.php');
require_once _PS_MODULE_DIR_ . 'checkoutklap/Model/KlapTransaction.php';
require_once _PS_MODULE_DIR_ . 'checkoutklap/Model/OrderPaymentOne.php';

use \Multicaja\Payments\Model\Error;
use \Multicaja\Payments\Model\OrderResponse;
use \Multicaja\Payments\Utils\PaymentsApiClient;
use \Multicaja\Payments\Utils\ValidateParams;

class CheckoutKlapCallbackHandlerModuleFrontController extends BaseController
{


  const PARA_ORDEN = '] para la orden, referenceId: ';
  const ORDERLOG = ', orderId: ';
  const FECHA = ', fecha: ';
  const TABLE_NAME = 'klap_transaction';

  /**
   * Busca la orden y retorna la respuesta, metodo de pago seleccionado y datos del pago
   */
  private function getOrderData($orderId)
  {
    //busca la orden en multicaja
    try {
      $environment = $this->hp->getEnvironment();
      $apikey = $this->hp->getApiKey();
      PaymentsApiClient::setLogger($this->hp->getLogger());
      $response = PaymentsApiClient::getOrder($environment, $apikey, $orderId);
    } catch (Exception $ex) {
      $this->logger->error('Error al obtener la orden: ' . $ex->getMessage() . ' - ' . $ex->getLine() . ' - ' . $ex->getFile());
      $response = new Error('1', 'Error al obtener la orden por id: ' . $orderId);
    }

    $amount = 0;
    $selectMethod = 'Error';
    $paymentDetails = 'Error';

    //obtiene el medio de pago seleccionado y los datos del pago
    if ($response instanceof OrderResponse) {
      if ($response->getSelectedMethod() != null) {
        $selectMethod = $response->getSelectedMethod()->getName();
      }
      if ($response->getPaymentDetails() != null) {
        $paymentDetails = json_encode($response->getPaymentDetails());
      }
      $amount = intval($response->getAmount()->getTotal());
    }

    return array(
      'amount' => $amount,
      'selectMethod' => $selectMethod,
      'paymentDetails' => $paymentDetails
    );
  }

  /**
   * Metodo por defecto a implementar en los controladores de Prestashop
   */
  public function initContent()
  {

    $paymentDate = $this->getCurrentDateTime();

    try {
      parent::initContent(); //es necesario llamar al initContent del padre

      $callback = isset($_GET['mcb']) ? $_GET['mcb'] : null;
      //permite capturar la validación del webhook o url de redireccion invocada desde el administrador del plugin
      //se usa simplemente para verificr que se puede llegar a el
      $test_access = isset($_GET['test_access']) ? $_GET['test_access'] : null;
      if ($test_access === 'true') {
        if ($callback === 'return_url' || $callback === 'cancel_url') {
          echo 'La url de redireccion [' . $callback . '] funciona correctamente';
        } else {
          echo 'El webhook [' . $callback . '] funciona correctamente';
        }
        die();
      }

      //maneja el callback cuando se redirecciona desde el pasarela front a las url de la orden: return_url o cancel_url
      if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        $referenceId = isset($_GET['referenceId']) ? $_GET['referenceId'] : null;
        $orderId = isset($_GET['orderId']) ? $_GET['orderId'] : null;
        // Pago anulado, pasarela redirecciona sin datos para identificar
        if ($referenceId == null) {
          if (MulticajaUtils::isPrestashop_1_7()) {
            $this->errors[] = $this->l('Error al procesar tu pago.');
            $this->redirectWithNotifications('index.php?controller=cart');
          } else if (MulticajaUtils::isPrestashop_1_6()) {
            Tools::redirect('index.php?controller=cart');
          }
        }

        if ($callback !== 'return_url' && $callback !== 'cancel_url') {
          throw new InvalidArgumentException('Error en el nombre de la url de redirección [' . $callback . self::PARA_ORDEN . $referenceId . self::ORDERLOG . $orderId);
        }

        $moduleId = $this->module->id;
        $cart = new Cart($referenceId);
        $customer = new Customer((int) $cart->id_customer);
        $secureKey = $customer->secure_key;
        $realOrderId = Order::getOrderByCartId($referenceId);
        $orderEcommerce = new Order($realOrderId);
        $orderStatus = $orderEcommerce->getCurrentState();

        //es orden pagada
        if (($orderStatus != null && $this->hp->compareStatus($orderStatus, $this->hp->getOrderStatusPaid())) || ($callback == 'return_url' && $referenceId != null && $orderId != null)) {
          if ($orderStatus == null) {
            $currencyId = intval($this->context->currency->id);
            $moduleName = $this->module->displayName;
            $this->module->validateOrder((int) $referenceId, $this->hp->getOrderStatusPendingPayment(), $cart->getOrderTotal(), $moduleName, 'Pago pending', [], $currencyId, false, $secureKey);
            $realOrderId = Order::getOrderByCartId($referenceId);
          }
          $this->logger->info('ESTATUS DE PAGO ' . $orderStatus . ', CON REFERENCE_ID= ' . $referenceId . ', ORDER_ID= ' . $orderId);
          Tools::redirect('index.php?controller=order-confirmation&id_cart=' . $referenceId . '&id_module=' . $moduleId . '&id_order=' . $realOrderId . '&key=' . $secureKey);
        } else {
          //es orden con error en pago o anulada
          //$recoverQueryParams = ['mcb' => 'return_url','token_cart' => md5(_COOKIE_KEY_.'recover_cart_'.$referenceId), 'recover_cart' => $referenceId, 'referenceId' => $referenceId];
          // $url = $this->context->link->getModuleLink('checkoutklap', 'CallbackHandler', $recoverQueryParams, true);
          // http://localhost:9092/es/pedido?step=3&recover_cart=$referenceId&token_cart=md5(_COOKIE_KEY_.'recover_cart_'.$referenceId) permite redirigir al checkout y compartir carrito
          $this->logger->info(($orderId == null ? 'USUARIO ANULO ' : 'ERROR EN PAGO DE ORDER_ID ' . $orderId . ', ') . ' REFERENCE_ID ' . $referenceId);
          Tools::redirect('index.php?controller=cart&id_cart=' . $referenceId . '&id_module=' . $moduleId . '&id_order=' . $realOrderId . '&key=' . $secureKey);
        }
      } else {
        //maneja el callback cuando se invoca desde pasarela a los webhooks de la orden: webhook_confirm o webhook_reject
        $rawPost = file_get_contents('php://input');
        $data = json_decode($rawPost, true);
        $this->logger->info('DATA WEBHOOK ' . json_encode($data));

        $orderId = isset($data['order_id']) ? $data['order_id'] : null;
        $referenceId = isset($data['reference_id']) ? intval($data['reference_id']) : null;

        if ($referenceId == null) {
          throw new InvalidArgumentException('Error en la invocación del webhook [' . $callback . '] referenceId inválido');
        }

        if ($orderId == null) {
          throw new InvalidArgumentException('Error en la invocación del webhook [' . $callback . '] orderId inválido');
        }

        if ($callback !== 'webhook_confirm' && $callback !== 'webhook_reject') {
          throw new InvalidArgumentException('Error en el nombre del webhook [' . $callback . self::PARA_ORDEN . $referenceId . self::ORDERLOG . $orderId);
        }

        $apikey = $this->hp->getApiKey();

        //verifica el apikey
        $valid = ValidateParams::validateHashApiKeyFromHeaders(apache_request_headers(), $referenceId, $orderId, $apikey);

        if (!$valid) {
          throw new InvalidArgumentException('Error en la autenticación del webhook [' . $callback . self::PARA_ORDEN . $referenceId . self::ORDERLOG . $orderId . self::FECHA . $paymentDate);
        }

        $order = new Order(Order::getOrderByCartId($referenceId));
        $orderStatus = $order->getCurrentState();
        //si es un pago exitoso
        if ($callback === 'webhook_confirm') {
          $moduleName = $this->module->displayName;
          $cart = new Cart($referenceId);
          if ($cart->id == null) {
            throw new InvalidArgumentException('ReferenceId (cart) no existe referenceId: ' . $referenceId . ' OrderId: ' . $orderId);
          }

          $amountCart = intval(number_format($cart->getOrderTotal(true, Cart::BOTH), 0, ',', ''));
          $amountWebhook = isset($data['amount']) ? intval(number_format($data['amount'], 0, ',', '')) : null;
          if ($amountCart != $amountWebhook) {
            throw new InvalidArgumentException('Error: Monto invalido [' . $callback . self::PARA_ORDEN . $referenceId . self::ORDERLOG . $orderId);
          }

          $currencyId = intval($this->context->currency->id);
          $customer = new Customer((int) $cart->id_customer);
          $secureKey = $customer->secure_key;


          $lastDigits = isset($data['last_digits']) ? $data['last_digits'] : null;

          if ($orderStatus == null) {
            $this->module->validateOrder((int) $referenceId, $this->hp->getOrderStatusPaid(), $cart->getOrderTotal(), $moduleName, 'Pago exitoso', [], $currencyId, false, $secureKey);
            $order = new Order(Order::getOrderByCartId($referenceId));
          } else {
            $order->setCurrentState($this->hp->getOrderStatusPaid());
          }

          $brand = isset($data['brand']) ? $data['brand'] : null;
          $lastDigits = isset($data['last_digits']) ? '**** **** **** ' . $data['last_digits'] : null;
          $cardLastDigits = isset($data['last_digits']) ? $data['last_digits'] : null;
          $cardHolder = $customer->firstname && $customer->lastname ? $customer->firstname . ' ' . $customer->lastname : null;
          $authorizationCode = isset($data['approval_code']) ? $data['approval_code'] : null;
          $installments = isset($data['quotas_number']) ? $data['quotas_number'] : null;
          $transactionType = isset($data['card_type']) ? $data['card_type'] == 'CREDIT' ? 'CREDITO' : 'DEBITO' : null;
          $amount = isset($data['amount']) ? $data['amount'] : null;

          $installmentsAmount = null;
          if ($amount && $installments && $transactionType == 'CREDITO') {
            $installmentsAmount = (string) number_format($amount / $installments, 2, '.', '');
            $this->logger->info('Monto de cada cuota: ' . $installmentsAmount);
          }

          $orderReference = $order->reference;
          $this->logger->info('orderReference: ' . $orderReference);
          $newData = [
            'transaction_id' => $orderId,
            'card_number' => $lastDigits,
            'card_brand' => $brand,
            'card_holder' => $cardHolder,
            'card_last_digits' => $cardLastDigits,
            'authorization_code' => $authorizationCode,
            'installments' => $installments,
            'transaction_type' => $transactionType,
            'installment_amount' => $installmentsAmount
          ];

          $this->logger->info('Informacion de pago con reference de order: ' . json_encode($newData));

          $result = OrderPaymentOne::updatePaymentByReference($orderReference, $newData);
          if ($result) {
            $this->logger->info('Informacion de guardada correctamente en ps_order_payment.');
          } else {
            $this->logger->info('Error al guardada informacion en ps_order_payment.');
          }

          try {
            $mcCode = isset($data['mc_code']) ? $data['mc_code'] : null;
            $transaction = new KlapTransaction();
            $transaction->cart_id = $referenceId;
            $transaction->order_id = $orderId;
            $transaction->mc_code = $mcCode;
            $transaction->pedido_id = $order->id;
            $transaction->status = KlapTransaction::STATUS_APPROVED;
            $transaction->klap_data = json_encode($data);
            $transaction->amount = $cart->getOrderTotal();
            $transaction->created_at = date('Y-m-d H:i:s');
            $transaction->save();
          } catch (Exception $ex) {
            $this->logger->error('Error al guardar transaction en DB - ' . $ex->getMessage());
          }
          $this->logger->info('Pago realizado con exito usando [Klap Checkout' . self::PARA_ORDEN . $referenceId . self::ORDERLOG . $orderId . self::FECHA . $paymentDate);
        } else {
          if ($orderStatus != null) {
            try {
              $order->setCurrentState($this->hp->getOrderStatusFailed());
              $sql = 'DELETE FROM ' . _DB_PREFIX_ . self::TABLE_NAME . ' WHERE `pedido_id` = "' . $order->id . '"';
              \Db::getInstance()->Execute($sql);
            } catch (Exception $ex) {
              $this->logger->error('Error al eliminar transaction en DB - order ' . $orderId . ' ,error: ' . $ex->getMessage());
            }
          }
          $this->logger->error('Pago rechazado o anulado usando [Klap Checkout' . self::PARA_ORDEN . $referenceId . self::ORDERLOG . $orderId . self::FECHA . $paymentDate);
        }
        header('HTTP/1.1 200 OK');
        die();
      }
    } catch (Exception $ex) {
      $this->logger->error('Error CallbackHandler: ' . $ex->getMessage() . ' - ' . $ex->getLine() . ' - ' . $ex->getFile());
      $this->logger->error($ex->getMessage() . self::FECHA . $paymentDate, $ex);
      header('HTTP/1.1 500 Internal Server Error');
      die();
    }
  }
}
